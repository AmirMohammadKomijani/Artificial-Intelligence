
def change():
    x = 0
    for i in range(2):
        x+=2
    return x
x = change()
print(x)
