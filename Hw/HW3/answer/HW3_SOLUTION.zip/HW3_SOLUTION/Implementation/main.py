import sudoku_solver_CSP, sudoku_solver_simple_back_tracking

def main():
    print("------------------------------------")
    sudoku_solver_CSP.main()
    print("------------------------------------")
    sudoku_solver_simple_back_tracking.main()
    print("------------------------------------")

main()