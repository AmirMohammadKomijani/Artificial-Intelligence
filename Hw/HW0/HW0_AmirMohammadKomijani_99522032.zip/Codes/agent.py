import random



#################################################################################
# Functions
#################################################################################

def ai_action(game_state):

    Ch_Idx = 0
    idx = 0
    indexes = list(range(25))
    condition = [
            # horizontal
            (game_state[0], game_state[1], game_state[2], game_state[3]),
            (game_state[1], game_state[2], game_state[3], game_state[4]),
            (game_state[5], game_state[6], game_state[7], game_state[8]),
            (game_state[6], game_state[7], game_state[8], game_state[9]),
            (game_state[10], game_state[11], game_state[12], game_state[13]),
            (game_state[11], game_state[12], game_state[13], game_state[14]),
            (game_state[15], game_state[16], game_state[17], game_state[18]),
            (game_state[16], game_state[17], game_state[18], game_state[19]),
            (game_state[20], game_state[21], game_state[22], game_state[23]),
            (game_state[21], game_state[22], game_state[23], game_state[24]),

            # vertical
            (game_state[0], game_state[5], game_state[10], game_state[15]),
            (game_state[5], game_state[10], game_state[15], game_state[20]),
            (game_state[1], game_state[6], game_state[11], game_state[16]),
            (game_state[6], game_state[11], game_state[16], game_state[21]),
            (game_state[2], game_state[7], game_state[12], game_state[17]),
            (game_state[7], game_state[12], game_state[17], game_state[22]),
            (game_state[3], game_state[8], game_state[13], game_state[18]),
            (game_state[8], game_state[13], game_state[18], game_state[23]),
            (game_state[4], game_state[9], game_state[14], game_state[19]),
            (game_state[9], game_state[14], game_state[19], game_state[24]),

            # diagonal
            (game_state[0], game_state[6], game_state[12], game_state[18]),
            (game_state[6], game_state[12], game_state[18], game_state[24]),
            (game_state[4], game_state[8], game_state[12], game_state[16]),
            (game_state[8], game_state[12], game_state[16], game_state[20]),
            (game_state[1], game_state[7], game_state[13], game_state[19]),
            (game_state[5], game_state[11], game_state[17], game_state[23]),
            (game_state[3], game_state[7], game_state[11], game_state[15]),
            (game_state[9], game_state[13], game_state[17], game_state[21]),

        ]

    Mycondition = [
            # horizontal
            (indexes[0], indexes[1], indexes[2], indexes[3]),
            (indexes[1], indexes[2], indexes[3], indexes[4]),
            (indexes[5], indexes[6], indexes[7], indexes[8]),
            (indexes[6], indexes[7], indexes[8], indexes[9]),
            (indexes[10], indexes[11], indexes[12], indexes[13]),
            (indexes[11], indexes[12], indexes[13], indexes[14]),
            (indexes[15], indexes[16], indexes[17], indexes[18]),
            (indexes[16], indexes[17], indexes[18], indexes[19]),
            (indexes[20], indexes[21], indexes[22], indexes[23]),
            (indexes[21], indexes[22], indexes[23], indexes[24]),

            # vertical
            (indexes[0], indexes[5], indexes[10], indexes[15]),
            (indexes[5], indexes[10], indexes[15], indexes[20]),
            (indexes[1], indexes[6], indexes[11], indexes[16]),
            (indexes[6], indexes[11], indexes[16], indexes[21]),
            (indexes[2], indexes[7], indexes[12], indexes[17]),
            (indexes[7], indexes[12], indexes[17], indexes[22]),
            (indexes[3], indexes[8], indexes[13], indexes[18]),
            (indexes[8], indexes[13], indexes[18], indexes[23]),
            (indexes[4], indexes[9], indexes[14], indexes[19]),
            (indexes[9], indexes[14], indexes[19], indexes[24]),

            # diagonal
            (indexes[0], indexes[6], indexes[12], indexes[18]),
            (indexes[6], indexes[12], indexes[18], indexes[24]),
            (indexes[4], indexes[8], indexes[12], indexes[16]),
            (indexes[8], indexes[12], indexes[16], indexes[20]),
            (indexes[1], indexes[7], indexes[13], indexes[19]),
            (indexes[5], indexes[11], indexes[17], indexes[23]),
            (indexes[3], indexes[7], indexes[11], indexes[15]),
            (indexes[9], indexes[13], indexes[17], indexes[21]),

        ]

    ''' Generate and play move from tic tac toe AI'''
    #################################################################################
    # "*** YOUR CODE HERE ***"
    #################################################################################
    #pass


    if game_state.count(2) > 0:
        return

    #not losing mode :
    output = 0
    for check in condition:
        if check.count(True) == 3:
            Ch_Idx = condition.index(check)
            idx = findIndex(check)
            output = Mycondition[Ch_Idx][idx]
        else:
            emptyStates = []
            for i in range(0,25):     
                if game_state[i] is None:
                    emptyStates.append(i)               
            output = random.choice(emptyStates)
    
    return output   


def findIndex(check):
    for idx in check:
        if idx is None:
            return idx
     